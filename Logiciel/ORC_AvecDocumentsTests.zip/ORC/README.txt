
lancer le logiciel avec init.rb