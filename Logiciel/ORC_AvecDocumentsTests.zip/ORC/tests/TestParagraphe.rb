# -*- coding: utf-8 -*-
require('../kernel/Paragraphe.rb')
##############################################################################
# Projet L3 Groupe 2 : Test Unitaire de la classe Paragraphe
#
# Teste les méthodes et fonctionnalités de la classe Paragraphe
#
# dernière modification :	11/04/07, N. Dupont
##############################################################################
pa1 = Paragraphe.creer(1,"para1","blabla")
puts pa1.afficher()
