# -*- coding: utf-8 -*-
require('../kernel/GestionnairePartie.rb')
##############################################################################
# Projet L3 Groupe 2 : Test Unitaire de la classe GestionnairePartie
#
# Teste les méthodes et fonctionnalités de la classe GestionnairePartie
#
# dernière modification :	11/04/07, N. Dupont
##############################################################################

puts GestionnairePartie.donnerNumeroPartieLibre()
