# -*- coding: utf-8 -*-
require('../kernel/Image.rb')
##############################################################################
# Projet L3 Groupe 2 : Test Unitaire de la classe Image
#
# Teste les m�thodes et fonctionnalit�s de la classe Image
#
# derni�re modification :	11/04/07, N. Dupont
##############################################################################
im1 = Image.creer(1,"image1","../imageTest.jpg")
puts im1.afficher()
